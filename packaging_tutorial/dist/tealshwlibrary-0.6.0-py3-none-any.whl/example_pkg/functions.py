class June_7:

    def is_prime(num):
        
        hundred_primes = [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97,101,103,107,109,113,127,131,137,139,149,151,157,163,167,173,179,181,191,193,197,199,211,223,227,229,233,239,241,251,257,263,269,271,277,281,283,293,307,311,313,317,331,337,347,349,353,359,367,373,379,383,389,397,401,409,419,421,431,433,439,443,449,457,461,463,467,479,487,491,499,503,509,521,523,541]

        if num in hundred_primes:
            return True

        if num < hundred_primes[-1]:
            return False

        if num <= 1 or num % 2 == 0:
            return False
        
        for x in range(1, int(num**0.5)):
            if num % x == 0:
                return True
        else:
            return False
    
    def factorial(num):
        if num == 0:
            return 0
        sum = 1
        for x in range(1, num+1):
            sum = sum * x
        return sum
    
    def integer_input():
        while True:
            try:
                return int(input("Please enter a positive integer: "))
            except:
                print("Invalid input; please try again...")
                pass
